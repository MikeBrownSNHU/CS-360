package com.example.cs360_inventory_application_mikebrown;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;

public class NotificationsActivity extends AppCompatActivity {

    private TextView tvPermissionStatus;
    private MaterialButton btnRequestSms;

    private SharedPreferences prefs;

    private static final String PREFS_NAME = "app_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            prefs.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
                            updatePermissionStatus();
                            Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                        } else {
                            prefs.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
                            updatePermissionStatus();
                            Toast.makeText(this, "Permission denied. SMS alerts disabled.", Toast.LENGTH_LONG).show();
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        btnRequestSms = findViewById(R.id.btnRequestSms);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        updatePermissionStatus();

        btnRequestSms.setOnClickListener(v -> requestSmsPermission());
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            prefs.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
            updatePermissionStatus();
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();

        } else {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void updatePermissionStatus() {
        boolean granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            tvPermissionStatus.setText("Permission status: Granted");
        } else {
            tvPermissionStatus.setText("Permission status: Not granted");
        }
    }
}
