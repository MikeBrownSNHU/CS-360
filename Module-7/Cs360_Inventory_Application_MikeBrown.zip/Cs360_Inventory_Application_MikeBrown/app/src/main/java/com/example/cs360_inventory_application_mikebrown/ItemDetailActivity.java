package com.example.cs360_inventory_application_mikebrown;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;

public class ItemDetailActivity extends AppCompatActivity {

    private TextView tvItemName;
    private TextView tvCurrentQty;

    private MaterialButton btnEditQty;
    private MaterialCardView cardEditQty;

    private MaterialButton btnMinus;
    private MaterialButton btnPlus;
    private TextInputEditText etEditQty;
    private MaterialButton btnSaveQty;

    private MaterialButton btnDeleteItem;

    private ItemDao itemDao;

    private int itemId;
    private String itemName;
    private int currentQty;

    // Must match NotificationsActivity / AddItemActivity
    private static final String PREFS_NAME = "app_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    // For grading/testing. (Optional improvement later: let user set phone number)
    private static final String TEST_PHONE_NUMBER = "5551234567";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        // Bind views
        tvItemName = findViewById(R.id.tvItemName);
        tvCurrentQty = findViewById(R.id.tvCurrentQty);

        btnEditQty = findViewById(R.id.btnEditQty);
        cardEditQty = findViewById(R.id.cardEditQty);

        btnMinus = findViewById(R.id.btnMinus);
        btnPlus = findViewById(R.id.btnPlus);
        etEditQty = findViewById(R.id.etEditQty);
        btnSaveQty = findViewById(R.id.btnSaveQty);

        btnDeleteItem = findViewById(R.id.btnDeleteItem);

        itemDao = new ItemDao(this);

        // Get item from intent (sent by InventoryActivity)
        itemId = getIntent().getIntExtra("item_id", -1);
        itemName = getIntent().getStringExtra("item_name");
        currentQty = getIntent().getIntExtra("item_qty", 0);

        if (itemId == -1) {
            Toast.makeText(this, "Item not found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if (itemName == null) itemName = "";

        // Populate UI
        tvItemName.setText(itemName);
        tvCurrentQty.setText(String.valueOf(currentQty));
        etEditQty.setText(String.valueOf(currentQty));

        // Start with edit card visible or hidden — your choice
        cardEditQty.setVisibility(View.GONE);

        // Toggle edit area
        btnEditQty.setOnClickListener(v -> {
            if (cardEditQty.getVisibility() == View.VISIBLE) {
                cardEditQty.setVisibility(View.GONE);
            } else {
                cardEditQty.setVisibility(View.VISIBLE);
                etEditQty.setText(String.valueOf(currentQty));
            }
        });

        // +/- buttons
        btnMinus.setOnClickListener(v -> adjustQty(-1));
        btnPlus.setOnClickListener(v -> adjustQty(1));

        // Save update (UPDATE)
        btnSaveQty.setOnClickListener(v -> saveUpdatedQty());

        // Delete (DELETE)
        btnDeleteItem.setOnClickListener(v -> deleteItem());
    }

    private void adjustQty(int delta) {
        int qty = parseQty(etEditQty);
        qty += delta;
        if (qty < 0) qty = 0;
        etEditQty.setText(String.valueOf(qty));
    }

    private void saveUpdatedQty() {
        int newQty = parseQty(etEditQty);

        // Update DB (name unchanged in your UI, only qty changes)
        boolean updated = itemDao.updateItem(itemId, itemName, newQty);

        if (updated) {
            currentQty = newQty;
            tvCurrentQty.setText(String.valueOf(currentQty));

            // ✅ SMS trigger on qty reaching 0
            maybeSendLowInventorySms(itemName, currentQty);

            Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show();
            finish(); // return to InventoryActivity; it reloads in onResume()
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem() {
        boolean deleted = itemDao.deleteItem(itemId);
        if (deleted) {
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Sends an SMS alert ONLY when:
     * - quantity == 0
     * - sms_enabled == true in SharedPreferences
     * - SEND_SMS permission is granted
     *
     * If denied/disabled, does nothing (app continues to work).
     */
    private void maybeSendLowInventorySms(String itemName, int quantity) {
        if (quantity != 0) return;

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean smsEnabled = prefs.getBoolean(KEY_SMS_ENABLED, false);
        if (!smsEnabled) return;

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return; // permission denied -> do nothing
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            String msg = "Low inventory: '" + itemName + "' is out of stock.";
            smsManager.sendTextMessage(TEST_PHONE_NUMBER, null, msg, null, null);

            Toast.makeText(this, "Low inventory SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // Never crash if SMS fails
            Toast.makeText(this, "SMS failed (alerts optional).", Toast.LENGTH_SHORT).show();
        }
    }

    private int parseQty(TextInputEditText editText) {
        String txt = editText.getText() == null ? "" : editText.getText().toString().trim();
        if (TextUtils.isEmpty(txt)) return 0;

        try {
            int v = Integer.parseInt(txt);
            return Math.max(v, 0);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
