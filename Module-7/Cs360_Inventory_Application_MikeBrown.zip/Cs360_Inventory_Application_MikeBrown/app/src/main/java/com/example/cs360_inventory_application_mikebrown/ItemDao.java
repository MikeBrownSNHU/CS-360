package com.example.cs360_inventory_application_mikebrown;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ItemDao {

    private final DatabaseHelper dbHelper;

    public ItemDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public long insertItem(String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COL_ITEM_NAME, name.trim());
        values.put(DatabaseHelper.COL_ITEM_QTY, quantity);

        return db.insert(DatabaseHelper.TABLE_ITEMS, null, values);
    }

    public boolean itemNameExists(String name) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_ITEMS,
                new String[]{ DatabaseHelper.COL_ITEM_ID },
                "LOWER(" + DatabaseHelper.COL_ITEM_NAME + ") = ?",
                new String[]{ name.trim().toLowerCase() },
                null, null, null
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }


    public List<InventoryItem> getAllItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<InventoryItem> items = new ArrayList<>();

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_ITEMS,
                null,
                null,
                null,
                null,
                null,
                DatabaseHelper.COL_ITEM_NAME + " ASC"
        );

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
            int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_QTY));

            items.add(new InventoryItem(id, name, qty));
        }

        cursor.close();
        return items;
    }

    public boolean updateItem(int id, String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COL_ITEM_NAME, name.trim());
        values.put(DatabaseHelper.COL_ITEM_QTY, quantity);

        int rows = db.update(
                DatabaseHelper.TABLE_ITEMS,
                values,
                DatabaseHelper.COL_ITEM_ID + "=?",
                new String[]{ String.valueOf(id) }
        );

        return rows > 0;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int rows = db.delete(
                DatabaseHelper.TABLE_ITEMS,
                DatabaseHelper.COL_ITEM_ID + "=?",
                new String[]{ String.valueOf(id) }
        );

        return rows > 0;
    }
}

