package com.example.cs360_inventory_application_mikebrown;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etUsername;
    private TextInputEditText etPassword;
    private MaterialButton btnLogin;
    private MaterialButton btnCreate;

    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreate = findViewById(R.id.btnCreate);

        userDao = new UserDao(this);

        btnLogin.setOnClickListener(v -> attemptLogin());
        btnCreate.setOnClickListener(v -> attemptCreateAccount());
    }

    private void attemptLogin() {
        String username = safeText(etUsername);
        String password = safeText(etPassword);

        if (!isValid(username, password)) return;

        if (userDao.validateUser(username, password)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, InventoryActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void attemptCreateAccount() {
        String username = safeText(etUsername);
        String password = safeText(etPassword);

        if (!isValid(username, password)) return;

        boolean created = userDao.createUser(username, password);
        if (created) {
            Toast.makeText(this, "Account created! Please log in.", Toast.LENGTH_SHORT).show();
            // optional: clear fields
            etPassword.setText("");
        } else {
            Toast.makeText(this, "Username already exists. Try another.", Toast.LENGTH_SHORT).show();
        }
    }

    private String safeText(TextInputEditText editText) {
        return editText.getText() == null ? "" : editText.getText().toString().trim();
    }

    private boolean isValid(String username, String password) {
        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Username required");
            return false;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password required");
            return false;
        }
        if (password.length() < 4) {
            etPassword.setError("Password must be at least 4 characters");
            return false;
        }
        return true;
    }
}
