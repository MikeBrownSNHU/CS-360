package com.example.cs360_inventory_application_mikebrown;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private MaterialButton btnAddNewItem;
    private TextInputEditText etSearch;
    private LinearLayout llItemsContainer;
    private MaterialButton btnSmsSettings;

    private ItemDao itemDao;
    private List<InventoryItem> allItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        btnAddNewItem = findViewById(R.id.btnAddNewItem);
        etSearch = findViewById(R.id.etSearch);
        llItemsContainer = findViewById(R.id.llItemsContainer);

        itemDao = new ItemDao(this);

        btnAddNewItem.setOnClickListener(v ->
                startActivity(new Intent(this, AddItemActivity.class))
        );

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderRows(filterItems(s.toString()));
            }
        });
        btnSmsSettings = findViewById(R.id.btnSmsSettings);

        btnSmsSettings.setOnClickListener(v ->
                startActivity(new Intent(this, NotificationsActivity.class))
        );

    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload from DB every time we come back (after add/edit/delete)
        allItems = itemDao.getAllItems();
        renderRows(allItems);
    }

    private List<InventoryItem> filterItems(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();
        if (q.isEmpty()) return allItems;

        List<InventoryItem> filtered = new ArrayList<>();
        for (InventoryItem item : allItems) {
            if (item.name.toLowerCase().contains(q)) {
                filtered.add(item);
            }
        }
        return filtered;
    }

    private void renderRows(List<InventoryItem> items) {
        llItemsContainer.removeAllViews();

        LayoutInflater inflater = LayoutInflater.from(this);

        for (InventoryItem item : items) {
            View row = inflater.inflate(R.layout.activity_row_inventory_item, llItemsContainer, false);


            android.widget.TextView tvRowItem = row.findViewById(R.id.tvRowItem);
            android.widget.TextView tvRowQty = row.findViewById(R.id.tvRowQty);
            MaterialButton btnViewItem = row.findViewById(R.id.btnViewItem);

            tvRowItem.setText(item.name);
            tvRowQty.setText(String.valueOf(item.quantity));

            btnViewItem.setOnClickListener(v -> {
                Intent intent = new Intent(this, ItemDetailActivity.class);
                intent.putExtra("item_id", item.id);
                intent.putExtra("item_name", item.name);
                intent.putExtra("item_qty", item.quantity);
                startActivity(intent);
            });

            llItemsContainer.addView(row);
        }
    }
}
