package com.example.cs360_inventory_application_mikebrown;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserDao {

    private final DatabaseHelper dbHelper;

    public UserDao(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COL_USERNAME, username.trim());
        values.put(DatabaseHelper.COL_PASSWORD, password);

        long result = db.insert(DatabaseHelper.TABLE_USERS, null, values);
        return result != -1; // -1 usually means constraint failed (username exists)
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String selection = DatabaseHelper.COL_USERNAME + "=? AND " + DatabaseHelper.COL_PASSWORD + "=?";
        String[] args = { username.trim(), password };

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,
                new String[]{ DatabaseHelper.COL_USER_ID },
                selection,
                args,
                null,
                null,
                null
        );

        boolean found = cursor.moveToFirst();
        cursor.close();
        return found;
    }
}
