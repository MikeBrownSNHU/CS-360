package com.example.cs360_inventory_application_mikebrown;

public class InventoryItem {
    public final int id;
    public final String name;
    public final int quantity;

    public InventoryItem(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }
}
